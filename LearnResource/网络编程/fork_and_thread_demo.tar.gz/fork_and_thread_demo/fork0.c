#include<stdio.h>
#include<unistd.h>
int g_value = 10, value = 0;
int main()
{
//    printf("pid=%d, ppid=%d\n", getpid(), getppid());
    pid_t pid;
    pid = fork();
    if(pid == 0)
    {
        return 0;
        exit(0);
        for(int i=0; i < g_value; i++){ value++;
            printf("child g_value = %d, value=%d \n", g_value, value);

        }
//        printf("child pid=%d, ppid=%d\n", getpid(), getppid());
//        printf("child end!\n");
    }
    else{
        for(int i=0; i < g_value; i++){
            value++;
        printf("father g_value = %d, value=%d \n", g_value, value);
        }
//        printf("father pid=%d, ppid=%d\n", getpid(), getppid());
//        printf("father end!\n");
    }
}
