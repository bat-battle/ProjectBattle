#include<stdio.h>
#include<unistd.h>
int g_value = 100;
int main()
{
    pid_t id = fork();
    if(id < 0)
    {
        //创建进程失败
        printf("error\n");

    }
    else if(id == 0)
    {
        //child
        g_value = 200;
        printf("child pid=%d,father ppid=%d \n",getpid(),getppid());
        printf("child &g_value=%p\n", &g_value);
        printf("child &g_value=%d\n", g_value);
    }
    else
    {
        //father
        printf("child pid=%d,father ppid=%d \n",getpid(),getppid());
        printf("father &g_value=%p\n", &g_value);
        printf("father &g_value=%d\n", g_value);
    }
    //printf("&g_value=%d\n", &g_value);
    //printf("g_value = %d\n",g_value);
    return 0;
//
}
